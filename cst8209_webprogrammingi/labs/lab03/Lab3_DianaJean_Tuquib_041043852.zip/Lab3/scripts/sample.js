
var index = prompt("Enter a number","");
var i = 0;

while (i < index) {
    document.writeln("value is: " + i + "</br>");
    i++;
}
