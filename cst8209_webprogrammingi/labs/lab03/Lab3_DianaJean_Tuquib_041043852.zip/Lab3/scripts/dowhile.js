// Setting Variables
var secret = 8;

// Do While Loop
do {
  // Code block
  var guess = prompt("Please choose a number between 1 and 10: ");
  document.writeln("</br>" + "You chose: " + guess);
  console.log("You chose " + guess);
//Do While Condition
} while (guess != secret);

// After user guesses the correct number
document.writeln("</br></br>" + "\"Congr8ulations! You did gr8 and got 8 right. :-) \"");
console.log("\"Congr8ulations! You did gr8 and got 8 right. :-) \"");
