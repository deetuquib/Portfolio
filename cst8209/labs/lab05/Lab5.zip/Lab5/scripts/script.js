//midterm JavaScript file

//the following serves only as data sample, you can use different books or more than 3
book1 = {
author: "William Shakespeare",
title : "The Tempest",
genre : "Historical Fiction"
};

book2 = {
author: "Stephen King",
title : "The Shining",
genre : "Horror"
};

book3 = {
author: "Anne Frank",
title : "The Diary of Anne Frank",
genre : "Non-Fiction"
};

var bookArray = [];
