
<?php 
$cssFile="index.css";
include("./common/header.php"); 
include("./common/footer.php"); // #6 include footer
?>
        <div class="container">
            <div class="mx-auto">
                <h1>Welcome to Online Registration</h1>
                <p>
                    If you have never used this before, you have to <a href="NewUser.php">sign up</a> first.
                    <br>
                    If you have already signed up, you can <a href="Login.php">log in</a> now.
                </p>
            </div>
        </div>



