<?php
include_once './Common/Classes.php';
include_once './Common/Functions.php';

if($_SERVER['REQUEST_METHOD'] === "GET")
{
    //add your code here to process get all restaurant review, get one restaurant review, and get restaurant names.

    exit();
}

else if ($_SERVER['REQUEST_METHOD'] === "PUT")
{
    //add your code here to modify the given restaurant review
 
    exit();
}
else if ($_SERVER['REQUEST_METHOD'] === "DELETE")
{
    //add your code here to delete the specified restaurant review.

    exit(); 
}
else if ($_SERVER['REQUEST_METHOD'] === "POST")
{
    //add your code here to save the new restaurant review.

    exit();
}


