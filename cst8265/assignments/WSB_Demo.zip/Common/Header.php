<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script><meta charset="UTF-8">
        <title>Final project Website</title>
    </head>
    <body style="margin-bottom: 100px">
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                    <div class="navbar-nav px-2 ">
                        <a class="nav-item nav-link" href="Index.php">Home</a>
                        <a class="nav-item nav-link" href="Registration.php">Registration</a>
                        <a class="nav-item nav-link" href="Login_V.php">Vulnerable Login</a>
                        <a class="nav-item nav-link" href="Login_S.php">Secure Login</a>
                    </div>
            </nav>
        </header>
        
        
        
